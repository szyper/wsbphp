<?php 
  $conn = new mysqli("localhost", "root", "", "wsb_2023l_5s6s");
 ?>